#' Function to load in a specific variable

#' @param dir path to temporary directory.
#' @param verbose  Should feedback be output to the console?

assignInNamespace(
	"loadVar", 
	function(dir, verbose=FALSE){
		# read in the file
		corals <- read.csv(file.path(dir, "coralList0.54.csv"), sep=";", header=TRUE, stringsAsFactors=F)

		return(corals)
	}, 
	ns="chronosphere")
